﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using Ortak_Olacaklar;
using System.IdentityModel.Tokens.Jwt;
using System.Text;
using System.Security.Claims;
using Microsoft.AspNetCore.Authorization;

namespace TOKEN_API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class GirisController : ControllerBase
    {
        private IConfiguration configuration;

        public GirisController(IConfiguration _conf)
        {
            this.configuration = _conf;
        }

        [HttpPost] //modeli json a serialize etmek gerekli ki mvcde çalışsın!!
        [Route("LoginUser")]
        public IActionResult AdminLogin(Login user)
        {
            IActionResult response;
            var IsUser = ControlUser(user.Username, user.Password); //kullanıcılık kontrolü !!
            if (IsUser)
            {
                if (user.Username == "admin")
                {

                    var tokenStr = CreateJsonWebToken(user); //token oluşturma şeyi bizden geldi !!
                    response = Ok(new { token = tokenStr });

                }
                else
                {
                    var tokenSt = CreateJsonWebToken(user); //token oluşturma şeyi bizden geldi !!
                    response = Ok(new { token = tokenSt });
                }


            }
            else
                response = Unauthorized();

            return response;
        }

        [HttpPost] //modeli json a serialize etmek gerekli ki mvcde çalışsın!!
        [Authorize(Policy = "OzelClaim")]
        [Route("AAA")]
        public IActionResult Login(Login user)
        {
            IActionResult response;
            var IsUser = ControlUser(user.Username, user.Password); //kullanıcılık kontrolü !!
            if (IsUser)
            {
                if (user.Username == "admin")
                {

                    var tokenStr = CreateJsonWebToken(user); //token oluşturma şeyi bizden geldi !!
                    response = Ok(new { token = tokenStr });

                }
                else
                {
                    var tokenSt = CreateJsonWebToken(user); //token oluşturma şeyi bizden geldi !!
                    response = Ok(new { token = tokenSt });
                }


            }
            else
                response = Unauthorized();

            return response;
        }

        private bool ControlUser(string userName, string password) //User Kontrolü buradan sağlanıyor !!
        {
            bool res = false;
            bool userExists = UserStore.Users.Any(u => u.UserName == userName);
            if (userName == "admin" && password == "admin")
            {
                res = true;
            }

            else if (userExists)
            {
                bool parolaKont = UserStore.Users.Any(u => u.Password == password);
                if (parolaKont) { res = true; }
                else { res = false; }
            }
            else
            {

            }
            return res;
        }
             private object CreateJsonWebToken(Login user)
        {

            var users = UserStore.Users.Where(y => y.UserName == user.Username);
            
            var claims = new List<Claim>();
            foreach (var userInfo in users)
            {
                claims.Add(new Claim(ClaimTypes.Name, userInfo.UserName));
                
                claims.Add(new Claim(ClaimTypes.Email, userInfo.Email));
                foreach(var ozel in userInfo.Rol)
                {
                    claims.Add(new Claim("ozel", ozel));
                }
            }
            var tokenHandler = new JwtSecurityTokenHandler();
            var key = Encoding.UTF8.GetBytes(configuration["JWT:Key"]);
            var tokenDescriptor = new SecurityTokenDescriptor
           
            {
                Subject = new ClaimsIdentity(claims),
                
                Expires = DateTime.UtcNow.AddHours(1),
                Issuer = configuration["JWT:Issuer"],
                Audience = configuration["JWT:Issuer"],
                SigningCredentials = new SigningCredentials(new SymmetricSecurityKey(key), SecurityAlgorithms.HmacSha256Signature)
            };

            var token = tokenHandler.CreateToken(tokenDescriptor);
            var tokenString = tokenHandler.WriteToken(token);

            return new JwtSecurityTokenHandler().WriteToken(token);

        }
        }

    }

