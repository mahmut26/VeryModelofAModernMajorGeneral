﻿namespace Ortak_Olacaklar
{
    public class UserStore
    {
        // Declare a public static list of User objects named 'Users'.
        // Being static, this list is shared across all instances of the UserStore class and accessible without creating an instance of the class.
        // This list is initialized with predefined user data.
        public static List<User> Users = new List<User>
        {
            new User { Id=1, UserName = "admin", Password = "password", Email="admin@Example.com", Rol = new List<string> { "Admin", "User" } },
            new User { Id=2, UserName = "user", Password = "password", Email="user@Example.com", Rol = new List<string> { "User" } },
            new User { Id=3, UserName = "test", Password = "password", Email="test@Example.com", Rol = new List<string> { "Admin" } }
        };
    }
}
