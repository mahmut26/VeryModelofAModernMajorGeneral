﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Modeller
{
    public class Etiket
    {
        public int EtiketId { get; set; }
        public string EtiketName { get; set; }
    }
}
