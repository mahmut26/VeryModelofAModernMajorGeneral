﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Modeller.Migrations
{
    /// <inheritdoc />
    public partial class init : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "etikets",
                columns: table => new
                {
                    EtiketId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    EtiketName = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_etikets", x => x.EtiketId);
                });

            migrationBuilder.CreateTable(
                name: "kategoris",
                columns: table => new
                {
                    KategoriId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    KategoriName = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_kategoris", x => x.KategoriId);
                });

            migrationBuilder.CreateTable(
                name: "kullanicis",
                columns: table => new
                {
                    KullaniciId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    KullaniciName = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    kayitTarihi = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_kullanicis", x => x.KullaniciId);
                });

            migrationBuilder.CreateTable(
                name: "yazars",
                columns: table => new
                {
                    YazarId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    YazarName = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    YazarDescription = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    KullaniciId = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_yazars", x => x.YazarId);
                    table.ForeignKey(
                        name: "FK_yazars_kullanicis_KullaniciId",
                        column: x => x.KullaniciId,
                        principalTable: "kullanicis",
                        principalColumn: "KullaniciId");
                });

            migrationBuilder.CreateTable(
                name: "makales",
                columns: table => new
                {
                    MakaleID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    MakaleName = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    MakaleIcerik = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    EklenmeTarihi = table.Column<DateTime>(type: "datetime2", nullable: false),
                    KategoriId = table.Column<int>(type: "int", nullable: false),
                    Begeni = table.Column<int>(type: "int", nullable: false),
                    YazarId = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_makales", x => x.MakaleID);
                    table.ForeignKey(
                        name: "FK_makales_kategoris_KategoriId",
                        column: x => x.KategoriId,
                        principalTable: "kategoris",
                        principalColumn: "KategoriId",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_makales_yazars_YazarId",
                        column: x => x.YazarId,
                        principalTable: "yazars",
                        principalColumn: "YazarId",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "makaleEtikets",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    EtiketId = table.Column<int>(type: "int", nullable: false),
                    MakaleID = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_makaleEtikets", x => x.Id);
                    table.ForeignKey(
                        name: "FK_makaleEtikets_etikets_EtiketId",
                        column: x => x.EtiketId,
                        principalTable: "etikets",
                        principalColumn: "EtiketId",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_makaleEtikets_makales_MakaleID",
                        column: x => x.MakaleID,
                        principalTable: "makales",
                        principalColumn: "MakaleID",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "resims",
                columns: table => new
                {
                    ResimId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    MakaleID = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_resims", x => x.ResimId);
                    table.ForeignKey(
                        name: "FK_resims_makales_MakaleID",
                        column: x => x.MakaleID,
                        principalTable: "makales",
                        principalColumn: "MakaleID",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "yorums",
                columns: table => new
                {
                    YorumId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    yorumicerik = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    MakaleID = table.Column<int>(type: "int", nullable: false),
                    EklenmeTarihi = table.Column<DateTime>(type: "datetime2", nullable: false),
                    Begeni = table.Column<int>(type: "int", nullable: false),
                    KullaniciId = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_yorums", x => x.YorumId);
                    table.ForeignKey(
                        name: "FK_yorums_kullanicis_KullaniciId",
                        column: x => x.KullaniciId,
                        principalTable: "kullanicis",
                        principalColumn: "KullaniciId",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_yorums_makales_MakaleID",
                        column: x => x.MakaleID,
                        principalTable: "makales",
                        principalColumn: "MakaleID",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_makaleEtikets_EtiketId",
                table: "makaleEtikets",
                column: "EtiketId");

            migrationBuilder.CreateIndex(
                name: "IX_makaleEtikets_MakaleID",
                table: "makaleEtikets",
                column: "MakaleID");

            migrationBuilder.CreateIndex(
                name: "IX_makales_KategoriId",
                table: "makales",
                column: "KategoriId");

            migrationBuilder.CreateIndex(
                name: "IX_makales_YazarId",
                table: "makales",
                column: "YazarId");

            migrationBuilder.CreateIndex(
                name: "IX_resims_MakaleID",
                table: "resims",
                column: "MakaleID");

            migrationBuilder.CreateIndex(
                name: "IX_yazars_KullaniciId",
                table: "yazars",
                column: "KullaniciId");

            migrationBuilder.CreateIndex(
                name: "IX_yorums_KullaniciId",
                table: "yorums",
                column: "KullaniciId");

            migrationBuilder.CreateIndex(
                name: "IX_yorums_MakaleID",
                table: "yorums",
                column: "MakaleID");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "makaleEtikets");

            migrationBuilder.DropTable(
                name: "resims");

            migrationBuilder.DropTable(
                name: "yorums");

            migrationBuilder.DropTable(
                name: "etikets");

            migrationBuilder.DropTable(
                name: "makales");

            migrationBuilder.DropTable(
                name: "kategoris");

            migrationBuilder.DropTable(
                name: "yazars");

            migrationBuilder.DropTable(
                name: "kullanicis");
        }
    }
}
