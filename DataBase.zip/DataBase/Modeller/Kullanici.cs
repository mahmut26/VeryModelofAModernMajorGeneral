﻿namespace Modeller
{
    public class Kullanici
    {
        public int KullaniciId { get; set; }
        public string KullaniciName { get; set; }
        public ICollection<Yazar> yazar { get; set; }

        public DateTime kayitTarihi { get; set; }

    }
}