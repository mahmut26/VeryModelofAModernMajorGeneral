﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Modeller
{
    public class Makale
    {
        public int MakaleID { get; set; }
        public string MakaleName { get; set; }
        public string MakaleIcerik { get; set; }
        public DateTime EklenmeTarihi { get; set; }
        public Kategori kategori { get; set; }
        public int Begeni { get; set; }
        public Yazar yazar { get; set; }

        public ICollection<Yorum> Yorumlar { get; set; }
    }


}
