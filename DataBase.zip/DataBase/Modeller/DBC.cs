﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Modeller
{
    public class DBC:DbContext
    {
        public DBC(DbContextOptions<DBC> options): base(options)
        {
        }
        public DbSet<Etiket> etikets { get; set; }
        public DbSet<Kategori> kategoris { get; set; }
        public DbSet<Kullanici> kullanicis { get; set; }
        public DbSet<MakaleEtiket> makaleEtikets { get; set; }
        public DbSet<Makale> makales { get; set; }
        public DbSet<Resim> resims { get; set; }
        public DbSet<Yazar> yazars { get; set; }
        public DbSet<Yorum> yorums { get; set; }

        //protected override void OnModelCreating(ModelBuilder modelBuilder)
        //{
        //    // Author ve Book arasındaki ilişkiyi tanımlama
        //    modelBuilder.Entity<Kullanici>()
        //        .HasOne(a => a.yazar)
        //        .withMany(b => b.Author)
        //        .HasForeignKey(b => b.AuthorId);

        //    base.OnModelCreating(modelBuilder);
        //}

    }
    public class dbID:IdentityDbContext<AppUser>
    {
        public dbID(DbContextOptions<dbID> options) : base(options)
        {

        }
    }
}
