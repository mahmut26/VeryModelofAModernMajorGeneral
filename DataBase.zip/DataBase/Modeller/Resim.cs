﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Modeller
{
    public class Resim
    {
        public int ResimId { get; set; }
        public Makale makale { get; set; }
    }
}
