﻿namespace Modeller
{
    public class Yazar
    {
        public int YazarId { get; set; }
        public string YazarName { get; set; }
        public string YazarDescription { get; set; }

        //public Makale makale { get; set; }
    }
}