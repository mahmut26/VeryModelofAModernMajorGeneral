﻿namespace Modeller
{
    public class Yorum
    {
        public int YorumId { get; set; }
        public string yorumicerik { get; set; }
        public Makale makale { get; set; }

        public DateTime EklenmeTarihi { get; set; }

        public int Begeni {  get; set; }
        public Kullanici kullanici { get; set; }
    }
}