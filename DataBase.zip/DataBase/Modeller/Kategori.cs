﻿namespace Modeller
{
    public class Kategori
    {
        public int KategoriId { get; set; }
        public string KategoriName { get; set; }


    }
}