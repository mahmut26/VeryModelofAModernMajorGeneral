﻿using Microsoft.AspNetCore.Mvc;

namespace DataBase.Controllers
{
    public class MakaleController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
