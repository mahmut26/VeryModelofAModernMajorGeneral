﻿using Microsoft.AspNetCore.Mvc;
using Modeller;
using Newtonsoft.Json;
using System.Text;

namespace DataBase.Controllers
{
    public class LoginController : Controller
    {
        private readonly HttpClient _httpClient;

        //public LoginController(HttpClient httpClient)
        //{
        //    _httpClient = httpClient;
        //}

        public IActionResult Index()
        {
            return View();
        }
        [HttpPost]
        public async Task<IActionResult> Index(KullaniciKontrol model)
        {
            if (ModelState.IsValid)
            {
                var json = JsonConvert.SerializeObject(model);
                var content = new StringContent(json, Encoding.UTF8, "application/json");

                var response = await _httpClient.PostAsync("https://api.yourdomain.com/login", content);

                if (response.IsSuccessStatusCode)
                {
                    // Giriş başarılı
                    return RedirectToAction("Index", "Home");
                }
                else
                {
                    // Giriş başarısız
                    ModelState.AddModelError(string.Empty, "Geçersiz giriş denemesi.");
                }
            }

            return View(model);
        }
        public IActionResult Create()
        {
            return View();
        }
        [HttpPost]
        public async Task<IActionResult> Create(Register model)
        {
            if (ModelState.IsValid)
            {
                var json = JsonConvert.SerializeObject(model);
                var content = new StringContent(json, Encoding.UTF8, "application/json");

                var response = await _httpClient.PostAsync("https://api.yourdomain.com/items", content);

                if (response.IsSuccessStatusCode)
                {
                    // Oluşturma başarılı
                    return RedirectToAction("Index", "Home");
                }
                else
                {
                    // Oluşturma başarısız
                    ModelState.AddModelError(string.Empty, "Oluşturma işlemi başarısız oldu.");
                }
            }

            return View(model);
        }
    }
}




