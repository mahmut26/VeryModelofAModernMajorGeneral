﻿using DataLayer.Model_Blog;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Blog_Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class KullaniciController : ControllerBase
    {
        public IActionResult BaslikGoster()
        {
            //Db den ÇEk !!
            return Ok();
        }
        public IActionResult Oku()
        {

            //MVC DEN GELSİN DB DEN DE ÇEKİP MVC YE GÖNDERSİN
            return Ok();
        }
    }
}
