﻿using DataLayer.Model_Blog;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Blog_Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class YazarController : ControllerBase
    {
        public IActionResult Yazilanlar()
        {
            //MVC'den gelen User Ayarlarına Göre Gelsin,Db de kontrol edilsin, kontrolden sonra da mvc ye dönsün
            return Ok();
        }
        
        [HttpPost]
        public async Task<IActionResult> MakaleYaz(Makale model)
        {
            //mvc den alsın, db ye yazsın

            //var a = model.MakaleName;
            //var b = model.MakaleIcerik;
            //var c = //dbden çekelim
            //var d = //db den çekelim

            //var json = JsonConvert.SerializeObject(model);
            //var content = new StringContent(json, Encoding.UTF8, "application/json");



            //var response = await _httpClient.PostAsync("https://api.yourdomain.com/login", content);

            //if (response.IsSuccessStatusCode)
            //{
            //    // Giriş başarılı
            //    return RedirectToAction("Index", "Home");
            //}
            //else
            //{
            //    // Giriş başarısız
            //    ModelState.AddModelError(string.Empty, "Geçersiz giriş denemesi.");
            //}


            return Ok(model);
        }
    }
}
