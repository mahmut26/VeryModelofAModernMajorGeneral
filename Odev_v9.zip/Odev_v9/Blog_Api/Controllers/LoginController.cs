﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using DataLayer.Model_Login;
using Microsoft.AspNetCore.Identity;
using System.Security.Claims;
using System.Text;

namespace Blog_Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class LoginController : ControllerBase
    {

        //mvc den alsın, db ye baksın ok ise user rolünü dönsün. Role göre de mvc kontrolcülere gidebilir.
        private IConfiguration configuration;

        public LoginController(IConfiguration _conf)
        {
            this.configuration = _conf;
        }

        [HttpPost] //modeli json a serialize etmek gerekli ki mvcde çalışsın!!
        [Route("LoginUser")]
        public IActionResult Login(Login user)
        {
            IActionResult response;
            var IsUser = ControlUser(user.Email, user.Password); //kullanıcılık kontrolü !!
            if (IsUser)
            {
                response = Ok();
            }
            else
                response = Unauthorized();

            return response;
        }
        private bool ControlUser(string userName, string password) //User Kontrolü buradan sağlanıyor !!
        {
            bool res = false;
            //bool userExists = UserStore.Users.Any(u => u.UserName == userName);
            //if (userName == "admin" && password == "admin")
            //{
            //    res = true;
            //}

            //else if (userExists)
            //{
            //    bool parolaKont = UserStore.Users.Any(u => u.Password == password);
            //    if (parolaKont) { res = true; }
            //    else { res = false; }
            //}
            //else
            //{

            //}
            return res;
        }
        private object CreateJsonWebToken(Login user)
        {

            //var users = UserStore.Users.Where(y => y.UserName == user.Username);

            //var claims = new List<Claim>();
            //foreach (var userInfo in users)
            //{
            //    claims.Add(new Claim(ClaimTypes.Name, userInfo.UserName));

            //    claims.Add(new Claim(ClaimTypes.Email, userInfo.Email));
            //    foreach (var ozel in userInfo.Rol)
            //    {
            //        claims.Add(new Claim("ozel", ozel));
            //    }
            //}
            //var tokenHandler = new JwtSecurityTokenHandler();
            //var key = Encoding.UTF8.GetBytes(configuration["JWT:Key"]);
            //var tokenDescriptor = new SecurityTokenDescriptor

            //{
            //    Subject = new ClaimsIdentity(claims),

            //    Expires = DateTime.UtcNow.AddHours(1),
            //    Issuer = configuration["JWT:Issuer"],
            //    Audience = configuration["JWT:Issuer"],
            //    SigningCredentials = new SigningCredentials(new SymmetricSecurityKey(key), SecurityAlgorithms.HmacSha256Signature)
            //};

            //var token = tokenHandler.CreateToken(tokenDescriptor);
            //var tokenString = tokenHandler.WriteToken(token);

            //return new JwtSecurityTokenHandler().WriteToken(token);

            return user;

        }
    }
}
