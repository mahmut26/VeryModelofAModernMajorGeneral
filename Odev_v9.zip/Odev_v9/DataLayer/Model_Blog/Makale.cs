﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataLayer.Model_Blog
{
    public class Makale
    {
        public int Id { get; set; }
        public string Baslik { get; set; }
        public string Icerik { get; set; }
        public ICollection<Resim> resim { get; set; }

        //public Yorum yorum { get; set; }
        public ICollection<Yazar> yazar { get; set; }

        public ICollection<Kategori> kategori { get; set; }


    }
}
