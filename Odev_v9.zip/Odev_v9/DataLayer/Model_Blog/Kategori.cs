﻿namespace DataLayer.Model_Blog
{
    public class Kategori
    {
        public int Id { get; set; }
        public string Name { get; set; }

    }
}