﻿namespace DataLayer.Model_Blog
{
    public class Resim
    {
        public int Id { get; set; }
        public string Name { get; set; }

    }
}