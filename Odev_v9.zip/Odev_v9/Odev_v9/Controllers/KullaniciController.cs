﻿using Microsoft.AspNetCore.Mvc;

namespace Odev_v9.Controllers
{
    public class KullaniciController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
