﻿using Microsoft.AspNetCore.Mvc;

namespace Odev_v9.Controllers
{
    public class YazarController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
