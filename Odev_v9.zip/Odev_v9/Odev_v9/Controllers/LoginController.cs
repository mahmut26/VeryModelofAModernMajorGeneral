﻿using Microsoft.AspNetCore.Mvc;

namespace Odev_v9.Controllers
{
    public class LoginController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
